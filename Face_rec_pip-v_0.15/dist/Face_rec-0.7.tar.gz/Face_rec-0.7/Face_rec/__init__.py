from Face_rec.FaceClass import FaceIndentity
import Face_rec.pickle 
import Face_rec.face_detection_model